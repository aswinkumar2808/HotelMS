package com.hotel.managementsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotel.managementsystem.entity.Room;

public interface RoomRepository extends JpaRepository<Room,Integer> {
	

}
