package com.hotel.managementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotel.managementsystem.entity.Room;
import com.hotel.managementsystem.repository.RoomRepository;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    @Autowired
    private RoomRepository roomRepository;

    @GetMapping
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    @PutMapping("/{room_number}")
    public Room updateRoom(@PathVariable int room_number, @RequestBody Room roomDetails) {
        Room room = roomRepository.findById(room_number).orElseThrow();
        room.setAvailability(roomDetails.getAvailability());
        room.setCustomerId(roomDetails.getCustomerId());
        if("vacant".equalsIgnoreCase(roomDetails.getAvailability())) {
        	room.setCustomerId(null);
        }
        return roomRepository.save(room);
    }
}
