package com.hotel.managementsystem.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Room {
	@Id
    private int roomNumber;
    private Long customerId;
    private String floor;
    private String availability; // "vacant" or "booked"
    private Double price;
	public Long getCustomerId() {
		return customerId;
		
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public int getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	public String getFloor() {
		return floor;
	}
	public void setFloor(String floor) {
		this.floor = floor;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}

     
}

