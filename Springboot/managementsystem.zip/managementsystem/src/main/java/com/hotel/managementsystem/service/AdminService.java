package com.hotel.managementsystem.service;

public interface AdminService {
	boolean adminLogin(String adminName,String password);
}
