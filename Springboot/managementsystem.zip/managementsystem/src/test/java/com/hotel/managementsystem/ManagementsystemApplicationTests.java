package com.hotel.managementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
