import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { BillService } from '../../services/bill.service';

@Component({
  selector: 'app-user-billpage',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user-billpage.component.html',
})
export class UserBillPageComponent implements OnInit {
  billId!: number;
  bill: any;
  

  constructor(
    private route: ActivatedRoute,
    private billingService: BillService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.billId = Number(this.route.snapshot.paramMap.get('billId'));

    this.fetchBill();
  }

  fetchBill() {
    this.billingService.getBill(this.billId).subscribe({
      next: (data) => {
        this.bill = data;
      },
      error: (err) => {
        console.error('Failed to fetch bill:', err);
        alert('Could not load bill info.');
      }
    });
  }

  payNow() {
    this.billingService.payBill(this.billId).subscribe({
      next: () => {
        alert('Payment successful!');
        this.router.navigate(['/homepage']); // or to a confirmation page
      },
      error: (err) => {
        console.error('Payment failed:', err);
        alert('Payment failed. Please try again.');
      }
    });
  }
}
