import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule, DecimalPipe } from '@angular/common';
import { BillService } from '../../services/bill.service';
import { ReservationService } from '../../reservation.service';

@Component({
  selector: 'app-user-checkout',
  standalone: true,
  imports: [CommonModule, DecimalPipe],
  templateUrl: './user-checkout.component.html',
})
export class UserCheckoutComponent implements OnInit {
  user: any = JSON.parse(localStorage.getItem('user') || '{}');
  reservation: any = {};
  rooms: any = JSON.parse(localStorage.getItem('rooms') || '{}');

  customerName = '';
  stayDuration = 0;
  roomCharge: number = 0;
  serviceCharge: number = 200;
  totalAmount: number = 0;

  constructor(
    private router: Router,
    private billingService: BillService,
    private reservationService: ReservationService
  ) {}

  ngOnInit(): void {
    const userId = this.user.id || this.user.userId;

    this.reservationService.getReservationsByUserId(userId).subscribe({
      next: (res) => {
        console.log('🔥 All reservations for user:', res);

        this.reservation = res[res.length - 1]; // select latest
        console.log('👉 Latest reservation used:', this.reservation);

        this.customerName = this.reservation.name || 'Guest';
        this.stayDuration = this.calculateStayDuration(
          this.reservation.checkInDate,
          this.reservation.checkOutDate
        );
        this.calculateCharges();
      },
      error: (err) => {
        console.error('❌ Error fetching reservation:', err);
      }
    });
  }

  calculateStayDuration(checkInDate: string, checkOutDate: string): number {
    if (!checkInDate || !checkOutDate) return 0;

    const checkIn = new Date(checkInDate);
    const checkOut = new Date(checkOutDate);

    const duration = Math.floor((checkOut.getTime() - checkIn.getTime()) / (1000 * 3600 * 24));
    return duration > 0 ? duration : 0;
  }

  calculateCharges() {
    const roomType = this.reservation.roomPreference?.toLowerCase();
    let amount = 0;

    switch (roomType) {
      case 'single':
        amount = 1000;
        break;
      case 'double':
        amount = 2000;
        break;
      case 'suite':
        amount = 4500;
        break;
      default:
        amount = 0;
    }

    this.roomCharge = amount * this.stayDuration;
    this.totalAmount = this.roomCharge + this.serviceCharge;
  }

  goToPayment() {
    const billData = {
      reservationId: this.reservation.id,
      userId: this.user.id,
      roomCharge: this.roomCharge,
      serviceCharge: this.serviceCharge
    };

    console.log('📦 Sending bill data:', billData);

    this.billingService.generateBill(billData).subscribe({
      next: (response: any) => {
        const billId = response.id;
        this.router.navigate([`/billing/${billId}/pay`]);
      },
      error: (err: any) => {
        console.error('❌ Error generating bill:', err);
        alert('Error generating the bill. Please try again.');
      }
    });
  }
}
