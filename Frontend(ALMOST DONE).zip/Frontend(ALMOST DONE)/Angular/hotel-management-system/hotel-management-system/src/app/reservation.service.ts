import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Reservation } from './reservation';

@Injectable({
  providedIn: 'root'
})
export class ReservationService {

  private baseURL: string = "http://localhost:8081/reservations"; // Base URL for reservations
  private baseURL2: string = "http://localhost:8081/employee";  // URL for employee related requests

  constructor(private httpClient: HttpClient) { }

  getReservationList(): Observable<Reservation[]> {
    return this.httpClient.get<Reservation[]>(`${this.baseURL}`);
  }

  // Fetch reservations by user ID (this is the method we will use in UserCheckoutComponent)
  getReservationsByUserId(userId: string): Observable<any> {
    return this.httpClient.get<any>(`${this.baseURL}?userId=${userId}`);
  }

  createReservation(reservation: Reservation): Observable<object> {
    return this.httpClient.post(`${this.baseURL}`, reservation);
  }

  getReservationByUserId(userId: number): Observable<Reservation[]> {
    return this.httpClient.get<Reservation[]>(`${this.baseURL2}/${userId}`);
  }

  updateReservation(id: number, reservation: Reservation): Observable<Reservation> {
    return this.httpClient.put<Reservation>(`${this.baseURL2}/${id}`, reservation);
  }

  deleteReservationById(id: number): Observable<object> {
    return this.httpClient.delete<Reservation>(`${this.baseURL2}/${id}`);
  }
  getUserReservations(userId: string): Observable<any> {
    return this.httpClient.get(`http://localhost:8081/${userId}`);
  }
  
}
