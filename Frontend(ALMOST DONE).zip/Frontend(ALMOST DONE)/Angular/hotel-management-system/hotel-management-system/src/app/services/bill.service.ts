import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BillService {
  private _url = 'http://localhost:8081/api/billing'; 

  constructor(private http: HttpClient) {}

  generateBill(data: any) {
    return this.http.post<any>('http://localhost:8081/api/billing/generate', data);
  }
  

  payBill(billId: number) {
    return this.http.put<any>(`${this._url}/${billId}/pay`, {});
  }

  getBill(billId: number) {
    return this.http.get<any>(`${this._url}/${billId}`);
  }
}
