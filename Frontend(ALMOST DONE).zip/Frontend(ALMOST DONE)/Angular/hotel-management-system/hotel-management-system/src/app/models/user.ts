export interface User {
    name: string,
    email: string,
    mobileNumber: string,
    address: string,
    loginId: string,
    password: string
}
